<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\ApplicationController;
use App\Http\Controllers\LoginController;
use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/register', [RegisterController::class, 'registerform'])->name('auth.register');
Route::post('/register', [RegisterController::class, 'register'])->name('auth.register');

Route::get('/login', [LoginController::class, 'loginform'])->name('auth.login');
Route::post('/login', [LoginController::class, 'login'])->name('auth.login');
Route::get('/logout', [LoginController::class, 'logout'])->name('auth.logout');

Route::get('/application', [ApplicationController::class, 'index'])->name('application.index');
Route::get('/application/create', [ApplicationController::class, 'create'])->name('application.create');
Route::post('/application/create', [ApplicationController::class, 'store'])->name('application.store');

Route::get('/admin', [AdminController::class, 'index'])->name('admin.index');
Route::patch('/logout', [AdminController::class, 'update'])->name('status.update');
