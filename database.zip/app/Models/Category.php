<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Department;
use App\Models\User;
use App\Models\Category;
use App\Models\Status;

class Category extends Model
{
    protected $fillable = ['category_name'];
    public function applications(){
    return $this->hasMany(Application::class);
}

}
