<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\Department;
use App\Models\User;
use App\Models\Category;
use App\Models\Status;

class Department extends Model
{
    protected $fillable = ['department _name'];
    public function user(){
    return $this->belongsTo(User::class);
}

}
