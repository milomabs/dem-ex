<?php

namespace App\Http\Controllers;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DepartmentController;
use App\Models\Department;
use App\Models\User;
use App\Models\Category;
use Illuminate\Support\Facades\Hash;
use App\Models\Status;
use Illuminate\Support\Facades\Auth;

class RegisterController extends Controller
{
    public function registerform(){
        $departments = ['departments' => Department::all()];
        return view('auth.register', $departments);
        }
        
        public function register(Request $request){
        $user = User::create([
        'name'=> $request->name,
        'last_name' => $request->last_name,
        'first_name' => $request->first_name,
        'patronym' => $request-> patronym,
        'phone' => $request->phone,
        'email' => $request->email,
        'department_id' => $request->department_id,
        'password' => Hash::make($request-> password)
        ]);
        event(new Registered($user));
        Auth::login($user);
        return redirect()->route('application.index');
        }
        
}
