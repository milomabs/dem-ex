<?php

namespace App\Http\Controllers;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\DepartmentController;
use App\Http\Controllers\ApplicationController;
use App\Http\Controllers\LoginController;
use App\Models\Department;
use App\Models\User;
use App\Models\Category;
use App\Models\Status;
use App\Models\Application;
use Illuminate\Support\Facades\Hash;

use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index(){
        $context = [
        'applications' => Application::latest()->get(),
        'statuses' => Status::all()
         ];
        return view('admin.index', $context);
        }
        
        public function update(Request $request, Application $application)
        {
        $application = Application::where('id', $request->application_id)->update([
        'status_id' => $request->status
        ]);
        return redirect()->route('admin.index');
        }
        
}
