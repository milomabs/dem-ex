<?php

namespace App\Http\Controllers;
use App\Models\Department;
use App\Models\User;
use App\Models\Category;
use App\Models\Status;
use App\Models\Application;
use Illuminate\Http\Request;
use Illuminate\Auth\Events\Registered;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\DepartmentController;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;


class ApplicationController extends Controller
{
    public function index(){
        $context = ['applications' => Auth::user()->applications()->latest()->get() ];
        return view('application.index', $context);
        }
        public function create(){
        $categories= ['categories' => Category::all() ];
        return view('application.create_application', $categories);
        }
        
        public function store(Request $request){
        Auth::user()->applications()->create([
        'description' => request('descriptionText'),
        'category_id' => $request->category,
        'status_id' => 1
        ]);
        return redirect()->route('application.index');
        }
        
}
