<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Department;
use App\Models\User;
use App\Models\Category;
use App\Models\Status;

class LoginController extends Controller
{
    public function loginform(){
        return view("auth.login");
        }
        
        public function login(Request $request){
        $success = auth()->attempt([
        "email" => $request->email,
        "password" => $request->password
        ], request()->has("remember"));
        
        If($success) {
        return redirect()->route("application.index"); }
        }
        
        public function logout(){
        auth()->logout();
        return redirect()->route("auth.login"); 
        }
        
}
