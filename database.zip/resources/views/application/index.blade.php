

<link rel="stylesheet" href="{{ asset('style.css') }}">@extends('layouts.base')
@section('title', 'Все заявки')
@section('main')
<h2>Мои заявки</h2>
<a href="{{ route('application.create') }}">Создать заявку</a>
@if (count($applications)>0)
<article>
@foreach ($applications as $application)
<p>{{  $application->description }}</p>
<p>{{  $application->created_at }}</p>
@endforeach
</article>
@else
<p>У вас нет заявок</p>
@endif
@endsection('main')
