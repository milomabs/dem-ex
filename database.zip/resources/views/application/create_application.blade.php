

<link rel="stylesheet" href="{{ asset('style.css') }}">@extends('layouts.base')
@section('title', 'Все заявки')
@section('main')
<h2>Добавление заявки</h2>
<a href="{{ route('application.create') }}">Создать заявку</a>

<form method="post" action='{{ route("application.store") }}'>
@csrf
<div class="line">
    <label for="descriptionText">Описание проблемы</label>
    <textarea name="descriptionText" id="descriptionText" rows="5"></textarea>
</div>
<div class="line">
    <label for="categoryText">Категория проблемы</label>
    <select name="category" id="categoryText">
        @foreach ($categories as $category)
        <option value="{{ $category->id }}">{{ $category-> category_name }}</option>
        @endforeach
    </select>
</div>
<div class="line">
    <button type="submit">Отправить</button>
</div>
</form>
@endsection('main')
