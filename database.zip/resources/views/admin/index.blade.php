
    <link rel="stylesheet" href="{{ asset('style.css') }}">

    @extends('layouts.base')
    @section('title', 
    'Панель администратора')
    @section('main')
<body>
    
</body>
<h2>все заявки</h2>
<div class="applications">
@if (count($applications)>0)
<article>
@foreach ($applications as $application)
<h3>Заявка № {{ $application->id }}</h3>
<p>{{ $application->user->first_name }}{{ $application->user->last_name }}{{ $application->user->patronym }}</p>
<p>{{ $application->user->department_id }}</p>
<p>{{ $application->category->category_name }}</p>
<p>{{ $application->description }}</p>

<div class="status-{{ $application->status->id }}">{{ $application->status->status_name }}</div>
<form action="{{ route('status.update') }}" method="post">
@csrf
@method('PATCH')
<input type="hidden" name="application_id" value="{{ $application->id }}">
<select name="status" id="statusText">
@foreach ($statuses as $status)
<option value="{{ $status->id }}">{{ $status->status_name }}</option>
@endforeach
</select>
<button type="submit">Обновить</button>
</form>
<span>{{ $application->created_at }}</span>
<p><a href="{{ route('status.update') }}">Изменить статус</a></p>
@endforeach
</article>
@else
<p>В настоящее время заявок нет</p>
@endif
</div>
</body>
@endsection('main')
