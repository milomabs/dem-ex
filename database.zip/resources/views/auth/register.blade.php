
<link rel="stylesheet" href="{{ asset('style.css') }}">
@extends('layouts.base')
@section('title', 'Регистрация')
@section('main')
<form method="post" action='{{ route("auth.register") }}'>
@csrf
<div class="line">
<label>Ваши ФИО</label>
<input id="last_name" name="last_name" type="text" placeholder="Фамилия">
<input id="first_name" name="first_name" type="text" placeholder="Имя">
<input id="patronym" name="patronym" type="text" placeholder="Отчество">
</div>

<div class="line">
<label for="name">Ваш логин </label>
<input id="name" name="name" type="text">
</div>

<div class="line">
<label for="email">Ваша почта</label>
<input id="email" name="email" type="email">
</div>

<div class="line">
<label for="phone">Ваш номер</label>
<input id="phone" name="phone" type="text">
</div>

<div class="line">
<label for="departmentText">Отдел в котором вы работаете</label>
<select name="department_id" id="departmentText">
@foreach ($departments as $department)
<option value="{{ $department->id }}">{{ $department->department_name }}</option>
@endforeach
</select>
</div>

<div class="line">
<label for="password">Ваш пароль</label>
<input id="password" name="password" type="password">
</div>

<div class="line">
<label for="password_confirmation">Ваш пароль</label>
<input id="password_confirmation" name="password_confirmation" type="password">
</div>

<div class="line">
<button type="submit">Регистрация</button>
</div>
</form>
<p>Есть учетная запись? <a href="{{ route('auth.login') }}">Авторизуйтесь</a></p>
@endsection('main')

</body>
</html>