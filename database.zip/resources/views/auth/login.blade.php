
<link rel="stylesheet" href="{{ asset('style.css') }}">
@section('title', 'Авторизация')
@section('main')
<form method="post" action='{{ route("auth.login") }}'>
@csrf

<div class="line">
<label for="email">Ваша почта</label>
<input id="email" name="email" type="email">
</div>

<div class="line">
<label for="password">Ваш пароль</label>
<input id="password" name="password" type="password">
</div>

<div class="line">
<button type="submit">Войти</button>
</div>
</form>
<p>Нет учетной записи? <a href="{{ route('auth.register') }}">Зарегистрируйтесь</a></p>
@endsection('main')
