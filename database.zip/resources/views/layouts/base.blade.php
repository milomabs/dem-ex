
    <link rel="stylesheet" href="{{ asset('style.css') }}">
    <title>@yield('title')</title>
</head>
<body>
    <div class="container">
    <h1>Сервис Help</h1>
    @auth
    <nav>
    <ul> 
    <li><a href="{{ route('application.index') }}">Мои заявки</a></li>
    <li><a href="{{ route('auth.logout') }}">Выход</a></li> 
    </ul>
    </nav>
    @endauth
    @yield('main')
    </div> 







